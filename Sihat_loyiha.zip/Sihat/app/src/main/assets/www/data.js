// Tayyor ma'lumotlar: mahalliy taomlar va mashq dasturlari.
// Kaloriya qiymatlari TAXMINIY (o'rtacha porsiya bo'yicha).
window.FOODS = [
  { name: "Osh (palov)", unit: "1 likopcha (~300 g)", kcal: 600 },
  { name: "Somsa (go'shtli)", unit: "1 dona", kcal: 300 },
  { name: "Lag'mon", unit: "1 kosa", kcal: 550 },
  { name: "Manti", unit: "1 dona", kcal: 110 },
  { name: "Chuchvara", unit: "1 kosa", kcal: 400 },
  { name: "Sho'rva", unit: "1 kosa", kcal: 250 },
  { name: "Mastava", unit: "1 kosa", kcal: 280 },
  { name: "Dimlama", unit: "1 likopcha", kcal: 350 },
  { name: "Shashlik (qo'y go'shti)", unit: "1 six", kcal: 200 },
  { name: "Shashlik (tovuq)", unit: "1 six", kcal: 130 },
  { name: "Non (obi non)", unit: "1/4 bo'lak", kcal: 170 },
  { name: "Qatiq", unit: "1 stakan (200 ml)", kcal: 120 },
  { name: "Tvorog", unit: "100 g", kcal: 160 },
  { name: "Tuxum (qaynatilgan)", unit: "1 dona", kcal: 75 },
  { name: "Guruch (qaynatilgan)", unit: "100 g", kcal: 130 },
  { name: "Grechka (qaynatilgan)", unit: "100 g", kcal: 110 },
  { name: "Tovuq ko'kragi", unit: "100 g", kcal: 165 },
  { name: "Mol go'shti (qaynatilgan)", unit: "100 g", kcal: 250 },
  { name: "Salat (pomidor-bodring)", unit: "1 likopcha", kcal: 60 },
  { name: "Olma", unit: "1 dona", kcal: 80 },
  { name: "Banan", unit: "1 dona", kcal: 105 },
  { name: "Uzum", unit: "100 g", kcal: 70 },
  { name: "Qovun", unit: "1 bo'lak (200 g)", kcal: 70 },
  { name: "Tarvuz", unit: "1 bo'lak (300 g)", kcal: 90 },
  { name: "Yong'oq", unit: "30 g", kcal: 195 },
  { name: "Choy (shakarsiz)", unit: "1 piyola", kcal: 2 },
  { name: "Choy (2 qoshiq shakar)", unit: "1 piyola", kcal: 40 },
  { name: "Kofe (sutli, shakarli)", unit: "1 stakan", kcal: 120 },
  { name: "Gazli ichimlik", unit: "0,5 l", kcal: 210 }
];

// met: jismoniy yuklama koeffitsienti (kaloriya hisobi uchun)
// sec: vaqt bo'yicha mashq; reps: takrorlar soni (u holda sec = taxminiy vaqt)
window.EXERCISES = {
  jumping:  { name: "Sakrab qo'l-oyoq ochish", desc: "Oyoqlarni yelka kengligida ochib sakrang, qo'llarni bosh ustida birlashtiring. Ritmni bir xil ushlang.", uz: "jumping jack mashqi", ru: "джампинг джек техника", met: 8 },
  march:    { name: "Joyida yurish", desc: "Tizzalarni baland ko'tarib, joyida tez yuring. Qo'llar ham harakatda bo'lsin.", uz: "joyida yurish mashqi", ru: "ходьба на месте с высоким подниманием колен", met: 4 },
  squat:    { name: "O'tirib turish", desc: "Oyoqlar yelka kengligida. Stulga o'tirayotgandek orqaga o'tiring, tizzalar oyoq uchidan chiqmasin. Orqa tik.", uz: "prisedaniya to'g'ri bajarish", ru: "приседания техника выполнения", met: 5 },
  lunge:    { name: "Oldinga qadam (vypad)", desc: "Bir oyoq bilan katta qadam tashlang va ikkala tizzani 90° ga bukib tushing. Navbat bilan almashtiring.", uz: "vypad mashqi", ru: "выпады техника выполнения", met: 5 },
  pushup:   { name: "Polga tayanib qo'l bukish", desc: "Tana to'g'ri chiziqda. Ko'krak polga yaqinlashguncha tushing. Qiyin bo'lsa, tizzaga tayanib bajaring.", uz: "otjimaniya to'g'ri bajarish", ru: "отжимания от пола техника", met: 6 },
  kneepush: { name: "Tizzada qo'l bukish", desc: "Tizzalarga tayangan holda qo'l bukish — boshlovchilar uchun yengil variant.", uz: "tizzada otjimaniya", ru: "отжимания с колен техника", met: 4 },
  plank:    { name: "Planka", desc: "Bilaklarga tayaning, tana boshdan tovongacha to'g'ri chiziq. Qorin tarang, bel pastga tushmasin.", uz: "planka mashqi", ru: "планка техника выполнения", met: 4 },
  crunch:   { name: "Qorin pressi", desc: "Chalqancha yotib, tizzalarni bukying. Yelkalarni poldan ko'tarib, qorinni qisib tushing. Bo'yinni tortmang.", uz: "qorin press mashqi", ru: "скручивания на пресс техника", met: 4 },
  legraise: { name: "Oyoq ko'tarish", desc: "Chalqancha yotib, to'g'ri oyoqlarni 90° gacha ko'taring va sekin tushiring. Bel polga yopishgan bo'lsin.", uz: "oyoq ko'tarish press", ru: "подъем ног лежа техника", met: 4 },
  bridge:   { name: "Ko'prikcha", desc: "Chalqancha yotib, tizzalarni bukying. Dumbani ko'tarib, yuqorida 1 soniya ushlang.", uz: "yagoditsa ko'prik mashqi", ru: "ягодичный мостик техника", met: 3.5 },
  climber:  { name: "Tog'ga chiqish", desc: "Planka holatida tizzalarni navbat bilan ko'krakka tez torting.", uz: "skalolaz mashqi", ru: "скалолаз упражнение техника", met: 8 },
  burpee:   { name: "Berpi", desc: "O'tiring, qo'llarga tayanib oyoqlarni orqaga tashlang, qaytib turing va sakrang.", uz: "berpi mashqi", ru: "берпи техника выполнения", met: 9 },
  wallsit:  { name: "Devorda o'tirish", desc: "Orqani devorga tirab, tizzalar 90° bo'lguncha tushing va ushlab turing.", uz: "devorda o'tirish mashqi", ru: "стульчик у стены упражнение", met: 4 },
  stretch:  { name: "Cho'zilish", desc: "Oyoq, bel va yelkalarni sekin cho'zing. Har bir holatni 15–20 soniya ushlang, chuqur nafas oling.", uz: "cho'zilish mashqlari", ru: "растяжка после тренировки", met: 2.5 },
  sideplank:{ name: "Yon planka", desc: "Bir bilakka yonbosh tayaning, tana to'g'ri chiziq. Har tomonga yarim vaqtdan.", uz: "yon planka", ru: "боковая планка техника", met: 4 }
};

window.PROGRAMS = [
  { id: "start", name: "Boshlovchilar uchun", level: "Yengil", rest: 20,
    items: [["march", 45], ["squat", 30], ["kneepush", 30], ["bridge", 30], ["crunch", 30], ["plank", 20], ["stretch", 60]] },
  { id: "fatburn", name: "Yog' yoqish", level: "O'rta", rest: 15,
    items: [["jumping", 40], ["squat", 40], ["climber", 30], ["lunge", 40], ["burpee", 30], ["jumping", 40], ["plank", 40], ["stretch", 60]] },
  { id: "abs", name: "Qorin mushaklari", level: "O'rta", rest: 15,
    items: [["crunch", 40], ["legraise", 30], ["plank", 40], ["sideplank", 40], ["climber", 30], ["crunch", 40], ["stretch", 45]] },
  { id: "legs", name: "Oyoq va dumba", level: "O'rta", rest: 20,
    items: [["squat", 45], ["lunge", 45], ["bridge", 40], ["wallsit", 40], ["squat", 45], ["stretch", 60]] },
  { id: "upper", name: "Qo'l va ko'krak", level: "O'rta", rest: 20,
    items: [["pushup", 30], ["plank", 40], ["kneepush", 30], ["sideplank", 40], ["pushup", 30], ["stretch", 45]] },
  { id: "hard", name: "Kuchli intensiv", level: "Qiyin", rest: 10,
    items: [["burpee", 40], ["climber", 40], ["squat", 45], ["pushup", 40], ["lunge", 45], ["burpee", 40], ["plank", 60], ["stretch", 60]] }
];
