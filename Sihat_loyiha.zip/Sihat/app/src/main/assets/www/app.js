/* Sihat — sport va vazn nazorati. Barcha ma'lumotlar telefonda (localStorage) saqlanadi. */
(function () {
  'use strict';

  // ---------- Yordamchilar ----------
  var KEY = 'sihat_v1';
  var A = window.Android || null; // Android ilovada mavjud ko'prik
  function T(s) { return I18N.t(s); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dkey(d) { d = d || new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function addDays(key, n) { var p = key.split('-'); var d = new Date(+p[0], +p[1] - 1, +p[2]); d.setDate(d.getDate() + n); return dkey(d); }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function num(v) { var n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? n : 0; }
  function r0(n) { return Math.round(n); }
  function r1(n) { return Math.round(n * 10) / 10; }
  var MONTHS = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentyabr', 'oktyabr', 'noyabr', 'dekabr'];
  function prettyDate(key) {
    if (key === dkey()) return T('Bugun');
    if (key === addDays(dkey(), -1)) return T('Kecha');
    var p = key.split('-'); return T(+p[2] + '-' + MONTHS[+p[1] - 1]);
  }
  function short(key) { var p = key.split('-'); return p[2] + '.' + p[1]; }

  function toast(msg) {
    var t = $('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }
  function openUrl(url) { if (A && A.openUrl) A.openUrl(url); else window.open(url, '_blank'); }
  function vibrate(ms) { try { if (A && A.vibrate) A.vibrate(ms); else if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

  // ---------- Holat ----------
  var S = load();
  function load() {
    var def = {
      profile: { sex: 'm', age: 30, height: 175, goalWeight: 70, stepGoal: 8000, kcalManual: 0, model: 'gemini-2.5-flash', apiKey: '' },
      script: 'cyr', weights: [], foods: {}, workouts: [], onboarded: false
    };
    try {
      var s = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (!s) return def;
      for (var k in def) if (!(k in s)) s[k] = def[k];
      for (var p in def.profile) if (!(p in s.profile)) s.profile[p] = def.profile[p];
      return s;
    } catch (e) { return def; }
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { toast(T('Saqlashda xato')); } }
  I18N.script = S.script;

  // ---------- Hisob-kitob ----------
  function lastWeight() { return S.weights.length ? S.weights[S.weights.length - 1].kg : 0; }
  function curWeight() { return lastWeight() || S.profile.goalWeight || 70; }
  function bmr() {
    var p = S.profile, w = curWeight();
    return 10 * w + 6.25 * p.height - 5 * p.age + (p.sex === 'm' ? 5 : -161);
  }
  function kcalGoal() {
    var p = S.profile;
    if (p.kcalManual > 0) return p.kcalManual;
    var t = bmr() * 1.4, w = lastWeight();
    if (w && p.goalWeight < w - 0.5) t -= 500;
    else if (w && p.goalWeight > w + 0.5) t += 300;
    return Math.max(p.sex === 'm' ? 1500 : 1200, r0(t / 10) * 10);
  }
  function foodsOf(key) { return S.foods[key] || []; }
  function eatenOf(key) { return foodsOf(key).reduce(function (a, f) { return a + (f.kcal || 0); }, 0); }
  function macrosOf(key) {
    return foodsOf(key).reduce(function (a, f) { a.p += f.p || 0; a.f += f.f || 0; a.c += f.c || 0; return a; }, { p: 0, f: 0, c: 0 });
  }
  function stepsHistory() {
    if (A && A.getStepHistory) { try { return JSON.parse(A.getStepHistory() || '{}'); } catch (e) {} }
    return {};
  }
  function stepsToday() { if (A && A.getStepsToday) { try { return A.getStepsToday(); } catch (e) {} } return null; }
  function stepKcal(steps) { return steps * 0.0005 * curWeight(); }
  function stepKm(steps) { return steps * (S.profile.height * 0.415) / 100000; }
  function workoutsOf(key) { return S.workouts.filter(function (w) { return w.d === key; }); }
  function burnedOf(key, steps) {
    return workoutsOf(key).reduce(function (a, w) { return a + w.kcal; }, 0) + stepKcal(steps || 0);
  }

  // ---------- Navigatsiya ----------
  var tab = 'home', foodDay = dkey();
  function go(t) { tab = t; render(); window.scrollTo(0, 0); }
  $$('#tabs button').forEach(function (b) { b.addEventListener('click', function () { go(b.getAttribute('data-tab')); }); });
  $('#scriptBtn').addEventListener('click', function () {
    S.script = S.script === 'cyr' ? 'lat' : 'cyr'; I18N.script = S.script; save(); render();
  });

  function render() {
    $$('[data-l]').forEach(function (el) { el.textContent = T(el.getAttribute('data-l')); });
    $$('#tabs button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === tab); });
    $('#topTitle').textContent = T('Sihat');
    $('#scriptBtn').textContent = S.script === 'cyr' ? 'Кирилл → Lotin' : 'Lotin → Кирилл';
    var v = $('#view');
    v.innerHTML = ({ home: viewHome, food: viewFood, train: viewTrain, weight: viewWeight, settings: viewSettings })[tab]();
    bind[tab] && bind[tab](v);
  }
  var bind = {};

  // ---------- Bosh sahifa ----------
  function ring(val, max, color) {
    var R = 54, C = 2 * Math.PI * R, p = Math.min(1, max ? val / max : 0);
    return '<svg class="ring" viewBox="0 0 132 132"><circle cx="66" cy="66" r="' + R + '" fill="none" stroke="#e7f6ef" stroke-width="12"/>' +
      '<circle cx="66" cy="66" r="' + R + '" fill="none" stroke="' + color + '" stroke-width="12" stroke-linecap="round" stroke-dasharray="' +
      (C * p) + ' ' + C + '" transform="rotate(-90 66 66)"/></svg>';
  }
  function viewHome() {
    var k = dkey(), st = stepsToday(), steps = st == null ? 0 : st, goal = kcalGoal(), eaten = r0(eatenOf(k));
    var burned = r0(burnedOf(k, steps)), left = goal - eaten + burned, m = macrosOf(k);
    var w = lastWeight(), first = S.weights.length ? S.weights[0].kg : 0;
    var h = '';
    h += '<div class="card"><div class="row">' +
      '<div style="position:relative">' + ring(eaten, goal + burned, eaten > goal + burned ? '#e8873a' : '#0f9d6b') +
      '<div style="position:absolute;inset:0;display:grid;place-items:center;text-align:center"><div><div class="mid">' + Math.abs(left) +
      '</div><div class="muted small">' + T(left >= 0 ? 'kkal qoldi' : 'kkal ortiqcha') + '</div></div></div></div>' +
      '<div style="flex:1"><div class="muted small">' + T('Kunlik maqsad') + '</div><div class="mid">' + goal + ' ' + T('kkal') + '</div>' +
      '<div class="muted small" style="margin-top:8px">' + T('Yeyildi') + ': <b>' + eaten + '</b></div>' +
      '<div class="muted small">' + T('Sarflandi') + ': <b>' + burned + '</b></div>' +
      '<div class="muted small">' + T('Oqsil') + ' ' + r0(m.p) + ' · ' + T("Yog'") + ' ' + r0(m.f) + ' · ' + T('Uglevod') + ' ' + r0(m.c) + ' ' + T('g') + '</div></div></div></div>';

    h += '<div class="card"><div class="row between"><b>' + T('Qadamlar') + '</b><span class="muted small">' + T('Maqsad') + ': ' + S.profile.stepGoal + '</span></div>';
    if (st == null) {
      h += '<div class="muted small" style="margin-top:6px">' + T("Qadam sanash faqat Android ilovada ishlaydi.") + '</div>';
    } else if (A && A.hasStepSensor && !A.hasStepSensor()) {
      h += '<div class="muted small" style="margin-top:6px">' + T("Telefoningizda qadam sensori topilmadi.") + '</div>';
    } else {
      h += '<div class="row between" style="margin-top:6px"><span class="big">' + steps + '</span><span class="muted">' + r1(stepKm(steps)) + ' ' + T('km') + ' · ' + r0(stepKcal(steps)) + ' ' + T('kkal') + '</span></div>' +
        '<div class="bar' + (steps >= S.profile.stepGoal ? '' : '') + '"><i style="width:' + Math.min(100, steps / S.profile.stepGoal * 100) + '%"></i></div>' +
        (A && A.needsStepPermission && A.needsStepPermission() ? '<button class="btn alt block" style="margin-top:10px" id="stepPerm">' + T('Qadam sanashga ruxsat berish') + '</button>' : '') +
        '<canvas class="chart" id="stepChart" style="height:120px;margin-top:10px"></canvas>';
    }
    h += '</div>';

    h += '<div class="grid2"><div class="card"><div class="muted small">' + T('Vazn') + '</div><div class="mid">' + (w ? r1(w) + ' ' + T('kg') : '—') + '</div>' +
      (w && first ? '<div class="small" style="color:' + (w <= first ? '#0f9d6b' : '#e8873a') + '">' + (w - first > 0 ? '+' : '') + r1(w - first) + ' ' + T('kg') + '</div>' : '') +
      '</div><div class="card"><div class="muted small">' + T('Maqsad vazn') + '</div><div class="mid">' + S.profile.goalWeight + ' ' + T('kg') + '</div>' +
      (w ? '<div class="small muted">' + T('Qoldi') + ': ' + r1(Math.abs(w - S.profile.goalWeight)) + ' ' + T('kg') + '</div>' : '') + '</div></div>';

    var wo = workoutsOf(k);
    h += '<div class="card"><div class="row between"><b>' + T('Bugungi mashqlar') + '</b><button class="btn alt" id="goTrain">' + T('Boshlash') + '</button></div>';
    h += wo.length ? '<div class="list">' + wo.map(function (x) {
      return '<div class="item"><span>' + esc(T(x.name)) + '</span><span class="muted small">' + x.min + ' ' + T('daq') + ' · ' + x.kcal + ' ' + T('kkal') + '</span></div>';
    }).join('') + '</div>' : '<div class="muted small" style="margin-top:6px">' + T("Bugun hali mashq qilinmadi.") + '</div>';
    h += '</div>';
    return h;
  }
  bind.home = function (v) {
    var g = $('#goTrain', v); if (g) g.onclick = function () { go('train'); };
    var p = $('#stepPerm', v); if (p) p.onclick = function () { A.requestStepPermission(); };
    var c = $('#stepChart', v);
    if (c) {
      var hist = stepsHistory(), labels = [], vals = [];
      for (var i = 6; i >= 0; i--) { var d = addDays(dkey(), -i); labels.push(short(d)); vals.push(d === dkey() ? (stepsToday() || 0) : (hist[d] || 0)); }
      barChart(c, labels, vals, S.profile.stepGoal);
    }
  };

  // ---------- Grafiklar (canvas) ----------
  function setupCanvas(c) {
    var dpr = window.devicePixelRatio || 1, w = c.clientWidth || 300, h = c.clientHeight || 160;
    c.width = w * dpr; c.height = h * dpr; var g = c.getContext('2d'); g.scale(dpr, dpr);
    g.font = '11px sans-serif'; return { g: g, w: w, h: h };
  }
  function barChart(c, labels, vals, goal) {
    var o = setupCanvas(c), g = o.g, max = Math.max.apply(null, vals.concat([goal || 1])) * 1.1, n = vals.length;
    var top = 6, bot = 18, bw = (o.w / n) * 0.6;
    for (var i = 0; i < n; i++) {
      var x = (o.w / n) * i + (o.w / n - bw) / 2, h = (o.h - top - bot) * (vals[i] / max);
      g.fillStyle = vals[i] >= goal ? '#0f9d6b' : '#9fd8c1';
      g.fillRect(x, o.h - bot - h, bw, h);
      g.fillStyle = '#6b7772'; g.textAlign = 'center'; g.fillText(labels[i], x + bw / 2, o.h - 4);
    }
    if (goal) {
      var gy = o.h - bot - (o.h - top - bot) * (goal / max);
      g.strokeStyle = '#e8873a'; g.setLineDash([4, 4]); g.beginPath(); g.moveTo(0, gy); g.lineTo(o.w, gy); g.stroke();
    }
  }
  function lineChart(c, pts, goal) {
    var o = setupCanvas(c), g = o.g;
    if (pts.length < 2) { g.fillStyle = '#6b7772'; g.textAlign = 'center'; g.fillText(T("Grafik uchun kamida 2 ta o'lchov kerak"), o.w / 2, o.h / 2); return; }
    var ys = pts.map(function (p) { return p.kg; }).concat(goal ? [goal] : []);
    var mn = Math.min.apply(null, ys) - 1, mx = Math.max.apply(null, ys) + 1, L = 34, R = 8, Tp = 8, B = 20;
    function X(i) { return L + (o.w - L - R) * (i / (pts.length - 1)); }
    function Y(v) { return Tp + (o.h - Tp - B) * (1 - (v - mn) / (mx - mn)); }
    g.strokeStyle = '#e3e8e5'; g.fillStyle = '#6b7772'; g.textAlign = 'right';
    for (var k = 0; k <= 3; k++) { var v = mn + (mx - mn) * k / 3, y = Y(v); g.beginPath(); g.moveTo(L, y); g.lineTo(o.w - R, y); g.stroke(); g.fillText(r1(v), L - 4, y + 4); }
    if (goal) { g.strokeStyle = '#e8873a'; g.setLineDash([4, 4]); g.beginPath(); g.moveTo(L, Y(goal)); g.lineTo(o.w - R, Y(goal)); g.stroke(); g.setLineDash([]); }
    g.strokeStyle = '#0f9d6b'; g.lineWidth = 2.5; g.beginPath();
    pts.forEach(function (p, i) { if (i) g.lineTo(X(i), Y(p.kg)); else g.moveTo(X(i), Y(p.kg)); }); g.stroke();
    g.fillStyle = '#0f9d6b'; pts.forEach(function (p, i) { g.beginPath(); g.arc(X(i), Y(p.kg), 3, 0, 7); g.fill(); });
    g.fillStyle = '#6b7772'; g.textAlign = 'left'; g.fillText(short(pts[0].d), L, o.h - 4);
    g.textAlign = 'right'; g.fillText(short(pts[pts.length - 1].d), o.w - R, o.h - 4);
  }

  // ---------- Ovqat ----------
  var MEALS = [['b', 'Nonushta'], ['l', 'Tushlik'], ['d', 'Kechki ovqat'], ['s', 'Tamaddi']];
  function mealNow() { var h = new Date().getHours(); return h < 11 ? 'b' : h < 16 ? 'l' : h < 21 ? 'd' : 's'; }
  function addFood(item) {
    var k = foodDay; (S.foods[k] = S.foods[k] || []).push({
      id: uid(), name: item.name, kcal: r0(item.kcal), p: r1(item.p || 0), f: r1(item.f || 0), c: r1(item.c || 0),
      meal: item.meal || mealNow(), note: item.note || ''
    });
    save();
  }
  function viewFood() {
    var k = foodDay, list = foodsOf(k), goal = kcalGoal(), eaten = r0(eatenOf(k)), m = macrosOf(k);
    var h = '<div class="card"><div class="row between"><button class="x" id="dPrev">‹</button><b>' + prettyDate(k) + '</b>' +
      '<button class="x" id="dNext"' + (k >= dkey() ? ' disabled style="opacity:.3"' : '') + '>›</button></div>' +
      '<div class="row between" style="margin-top:8px"><span class="big">' + eaten + '</span><span class="muted">/ ' + goal + ' ' + T('kkal') + '</span></div>' +
      '<div class="bar' + (eaten > goal ? ' over' : '') + '"><i style="width:' + Math.min(100, eaten / goal * 100) + '%"></i></div>' +
      '<div class="muted small" style="margin-top:8px">' + T('Oqsil') + ' ' + r0(m.p) + T('g') + ' · ' + T("Yog'") + ' ' + r0(m.f) + T('g') + ' · ' + T('Uglevod') + ' ' + r0(m.c) + T('g') + '</div></div>';
    h += '<div class="actions">' +
      '<button class="action" id="addScan"><span class="ai">▥</span>' + T('Shtrix-kod') + '</button>' +
      '<button class="action" id="addPhoto"><span class="ai">📷</span>' + T('Rasmdan ([[AI]])') + '</button>' +
      '<button class="action" id="addList"><span class="ai">🍲</span>' + T('Milliy taomlar') + '</button>' +
      '<button class="action" id="addManual"><span class="ai">✎</span>' + T("Qo'lda kiritish") + '</button></div>';
    MEALS.forEach(function (ml) {
      var items = list.filter(function (f) { return f.meal === ml[0]; });
      if (!items.length) return;
      var sum = items.reduce(function (a, f) { return a + f.kcal; }, 0);
      h += '<h2>' + T(ml[1]) + ' <span class="muted small">· ' + sum + ' ' + T('kkal') + '</span></h2><div class="card list">' +
        items.map(function (f) {
          return '<div class="item"><div><div class="nm">' + esc(f.name) + '</div>' + (f.note ? '<div class="muted small">' + esc(f.note) + '</div>' : '') +
            '</div><div class="row"><b>' + f.kcal + '</b><button class="x" data-del="' + f.id + '">×</button></div></div>';
        }).join('') + '</div>';
    });
    if (!list.length) h += '<div class="empty">' + T("Hali hech narsa qo'shilmadi. Yuqoridagi tugmalardan birini bosing.") + '</div>';
    return h;
  }
  bind.food = function (v) {
    $('#dPrev', v).onclick = function () { foodDay = addDays(foodDay, -1); render(); };
    $('#dNext', v).onclick = function () { if (foodDay < dkey()) { foodDay = addDays(foodDay, 1); render(); } };
    $('#addManual', v).onclick = function () { manualModal(); };
    $('#addList', v).onclick = listModal;
    $('#addScan', v).onclick = scanModal;
    $('#addPhoto', v).onclick = photoModal;
    $$('[data-del]', v).forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute('data-del');
        S.foods[foodDay] = foodsOf(foodDay).filter(function (f) { return f.id !== id; }); save(); render();
      };
    });
  };

  function mealSelect(sel) {
    sel = sel || mealNow();
    return '<label class="f">' + T('Ovqat vaqti') + '</label><select id="fMeal">' + MEALS.map(function (m) {
      return '<option value="' + m[0] + '"' + (m[0] === sel ? ' selected' : '') + '>' + T(m[1]) + '</option>';
    }).join('') + '</select>';
  }

  function manualModal(pre) {
    pre = pre || {};
    var md = modal(T("Qo'lda kiritish"),
      '<label class="f">' + T('Nomi') + '</label><input type="text" id="fName" value="' + esc(pre.name || '') + '">' +
      '<div class="grid2"><div><label class="f">' + T('Kaloriya (kkal)') + '</label><input type="number" inputmode="decimal" id="fKcal" value="' + (pre.kcal || '') + '"></div>' +
      '<div><label class="f">' + T('Oqsil (g)') + '</label><input type="number" inputmode="decimal" id="fP" value="' + (pre.p || '') + '"></div>' +
      '<div><label class="f">' + T("Yog' (g)") + '</label><input type="number" inputmode="decimal" id="fF" value="' + (pre.f || '') + '"></div>' +
      '<div><label class="f">' + T('Uglevod (g)') + '</label><input type="number" inputmode="decimal" id="fC" value="' + (pre.c || '') + '"></div></div>' +
      mealSelect(pre.meal) +
      '<button class="btn block" style="margin-top:14px" id="fSave">' + T("Qo'shish") + '</button>');
    $('#fSave', md).onclick = function () {
      var name = $('#fName', md).value.trim(), kcal = num($('#fKcal', md).value);
      if (!name || !kcal) { toast(T('Nomi va kaloriyasini kiriting')); return; }
      addFood({ name: name, kcal: kcal, p: num($('#fP', md).value), f: num($('#fF', md).value), c: num($('#fC', md).value), meal: $('#fMeal', md).value, note: pre.note });
      closeModal(); render(); toast(T("Qo'shildi"));
    };
  }

  function listModal() {
    var md = modal(T('Milliy taomlar'),
      '<input type="text" id="fq" placeholder="' + esc(T('Qidirish...')) + '">' +
      '<div class="muted small" style="margin:8px 2px">' + T("Kaloriya o'rtacha porsiya bo'yicha, taxminiy.") + '</div>' +
      '<div class="card list" id="fl"></div>');
    function fill(q) {
      q = (q || '').toLowerCase();
      $('#fl', md).innerHTML = FOODS.filter(function (f) {
        return !q || f.name.toLowerCase().indexOf(q) >= 0 || I18N.toCyr(f.name).toLowerCase().indexOf(q) >= 0;
      }).map(function (f, i) {
        return '<div class="item" data-i="' + FOODS.indexOf(f) + '"><div><div class="nm">' + esc(T(f.name)) + '</div><div class="muted small">' + esc(T(f.unit)) + '</div></div>' +
          '<div class="row"><b>' + f.kcal + '</b><button class="btn alt" style="padding:8px 12px">+</button></div></div>';
      }).join('');
      $$('[data-i]', md).forEach(function (row) {
        row.onclick = function () {
          var f = FOODS[+row.getAttribute('data-i')];
          portionModal(T(f.name), f.kcal, T(f.unit));
        };
      });
    }
    fill(''); $('#fq', md).oninput = function () { fill(this.value); };
  }

  function portionModal(name, kcalPer, unitLabel, per100, depth) {
    // per100: {p,f,c} 100 g uchun bo'lsa — grammda so'raladi
    var md = modal(name,
      '<div class="muted">' + esc(unitLabel) + ' = <b>' + r0(kcalPer) + '</b> ' + T('kkal') + '</div>' +
      '<label class="f">' + (per100 ? T('Necha gramm?') : T('Nechta porsiya?')) + '</label>' +
      '<input type="number" inputmode="decimal" id="pq" value="' + (per100 ? 100 : 1) + '">' +
      mealSelect() + '<div class="mid" style="margin-top:12px" id="pTot"></div>' +
      '<button class="btn block" style="margin-top:12px" id="pSave">' + T("Qo'shish") + '</button>');
    function tot() { var q = num($('#pq', md).value); return per100 ? kcalPer * q / 100 : kcalPer * q; }
    function upd() { $('#pTot', md).textContent = r0(tot()) + ' ' + T('kkal'); }
    $('#pq', md).oninput = upd; upd();
    $('#pSave', md).onclick = function () {
      var q = num($('#pq', md).value); if (!q) return;
      var k = per100 ? q / 100 : 0;
      addFood({ name: name, kcal: tot(), meal: $('#fMeal', md).value,
        p: per100 ? per100.p * k : 0, f: per100 ? per100.f * k : 0, c: per100 ? per100.c * k : 0,
        note: per100 ? q + ' ' + T('g') : (q !== 1 ? q + ' × ' + unitLabel : unitLabel) });
      for (var i = 0; i < (depth || 2); i++) closeModal();
      render(); toast(T("Qo'shildi"));
    };
  }

  // ---------- Kamera ----------
  var camStream = null, zxReader = null;
  function stopCam() {
    if (zxReader) { try { zxReader.reset(); } catch (e) {} zxReader = null; }
    if (camStream) { camStream.getTracks().forEach(function (t) { t.stop(); }); camStream = null; }
  }

  function scanModal() {
    var md = modal(T('Shtrix-kodni skanerlash'),
      '<div class="cam"><video id="cv" playsinline muted autoplay></video><div class="frame"></div></div>' +
      '<div class="muted small" id="cs" style="margin:10px 2px">' + T("Kamerani mahsulot shtrix-kodiga qarating.") + '</div>' +
      '<div class="row"><input type="number" inputmode="numeric" id="cCode" placeholder="' + esc(T('Yoki kodni yozing')) + '">' +
      '<button class="btn" id="cGo">' + T('Izlash') + '</button></div>', stopCam);
    $('#cGo', md).onclick = function () { var c = $('#cCode', md).value.trim(); if (c) lookup(c); };
    if (!window.ZXing) { $('#cs', md).textContent = T('Skaner kutubxonasi yuklanmadi. Kodni qo\'lda yozing.'); return; }
    try {
      zxReader = new ZXing.BrowserMultiFormatReader();
      zxReader.decodeFromConstraints({ video: { facingMode: 'environment' } }, $('#cv', md), function (res) {
        if (res && zxReader) { vibrate(80); var code = res.getText(); stopCam(); lookup(code); }
      }).catch(camErr);
    } catch (e) { camErr(e); }
    function camErr(e) { $('#cs', md).textContent = T("Kamerani ochib bo'lmadi. Ruxsat bering yoki kodni qo'lda yozing.") + ' (' + (e && e.name || e) + ')'; }
    function lookup(code) {
      $('#cs', md).innerHTML = '<span class="spin"></span> ' + T('Qidirilmoqda') + ': ' + esc(code);
      fetch('https://world.openfoodfacts.org/api/v2/product/' + encodeURIComponent(code) + '.json?fields=product_name,product_name_uz,product_name_ru,brands,nutriments,serving_size')
        .then(function (r) { return r.json(); })
        .then(function (j) {
          var p = j && j.product, n = p && p.nutriments;
          var kcal = n && (n['energy-kcal_100g'] || (n['energy_100g'] ? n['energy_100g'] / 4.184 : 0));
          if (!p || !kcal) {
            $('#cs', md).textContent = T("Bu mahsulot bazada topilmadi. Qadoqdagi kaloriyani qo'lda kiriting.");
            setTimeout(function () { closeModal(); manualModal({ note: T('Shtrix-kod') + ': ' + code }); }, 1400);
            return;
          }
          var name = (p.product_name_uz || p.product_name_ru || p.product_name || code) + (p.brands ? ' (' + p.brands.split(',')[0] + ')' : '');
          closeModal();
          portionModal(name, kcal, '100 ' + T('g'), { p: n.proteins_100g || 0, f: n.fat_100g || 0, c: n.carbohydrates_100g || 0 }, 1);
        })
        .catch(function () { $('#cs', md).textContent = T("Internet bilan bog'lanib bo'lmadi."); });
    }
  }

  function photoModal() {
    if (!S.profile.apiKey) {
      var m0 = modal(T('Rasmdan kaloriya'),
        '<p>' + T("Bu funksiya [[Google Gemini]] sun'iy intellekti orqali ishlaydi va bepul kalit talab qiladi.") + '</p>' +
        '<p class="muted small">' + T("Kalitni olish: [[aistudio.google.com/apikey]] saytiga [[Google]] akkauntingiz bilan kiring, «[[Create API key]]» tugmasini bosing va kalitni Sozlamalarga joylang.") + '</p>' +
        '<button class="btn block" id="gk">' + T('Kalit olish sahifasini ochish') + '</button>' +
        '<button class="btn alt block" style="margin-top:8px" id="gs">' + T('Sozlamalarga o\'tish') + '</button>');
      $('#gk', m0).onclick = function () { openUrl('https://aistudio.google.com/apikey'); };
      $('#gs', m0).onclick = function () { closeModal(); go('settings'); };
      return;
    }
    var md = modal(T('Rasmdan kaloriya'),
      '<div class="cam" id="pc"><video id="pv" playsinline muted autoplay></video></div>' +
      '<div class="muted small" id="ps" style="margin:10px 2px">' + T("Taomni yuqoridan, butun likopcha ko'rinadigan qilib suratga oling.") + '</div>' +
      '<div class="grid2"><button class="btn" id="pShot">' + T('Suratga olish') + '</button>' +
      '<button class="btn alt" id="pPick">' + T('Galereyadan') + '</button></div>' +
      '<input type="file" accept="image/*" id="pFile" style="display:none"><div id="pRes"></div>', stopCam);
    var video = $('#pv', md);
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1280 } } })
        .then(function (s) { camStream = s; video.srcObject = s; })
        .catch(function () { $('#ps', md).textContent = T("Kamerani ochib bo'lmadi. Galereyadan tanlang."); });
    }
    $('#pShot', md).onclick = function () {
      if (!video.videoWidth) { toast(T('Kamera hali tayyor emas')); return; }
      var c = document.createElement('canvas'), sc = Math.min(1, 1024 / Math.max(video.videoWidth, video.videoHeight));
      c.width = video.videoWidth * sc; c.height = video.videoHeight * sc;
      c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
      analyse(c.toDataURL('image/jpeg', 0.82));
    };
    $('#pPick', md).onclick = function () { $('#pFile', md).click(); };
    $('#pFile', md).onchange = function () {
      var f = this.files && this.files[0]; if (!f) return;
      var img = new Image(), url = URL.createObjectURL(f);
      img.onload = function () {
        var c = document.createElement('canvas'), sc = Math.min(1, 1024 / Math.max(img.width, img.height));
        c.width = img.width * sc; c.height = img.height * sc; c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url); analyse(c.toDataURL('image/jpeg', 0.82));
      };
      img.src = url;
    };
    function analyse(dataUrl) {
      stopCam();
      $('#pc', md).innerHTML = '<img src="' + dataUrl + '">';
      $('#pShot', md).disabled = true; $('#pPick', md).disabled = true;
      $('#ps', md).innerHTML = '<span class="spin"></span> ' + T('Tahlil qilinmoqda...');
      var prompt = 'Rasmdagi taomlarni aniqla va har birining taxminiy og\'irligi va ozuqaviy qiymatini hisobla. ' +
        'Faqat JSON qaytar: {"items":[{"name":"taom nomi o\'zbek tilida lotin yozuvida","grams":0,"kcal":0,"protein":0,"fat":0,"carbs":0}]}. ' +
        'O\'zbek milliy taomlarini (osh, somsa, lag\'mon, manti, sho\'rva va h.k.) to\'g\'ri nomla. Agar rasmda ovqat bo\'lmasa, items bo\'sh ro\'yxat bo\'lsin.';
      fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(S.profile.model || 'gemini-2.5-flash') + ':generateContent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': S.profile.apiKey },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: 'image/jpeg', data: dataUrl.split(',')[1] } }] }],
          generationConfig: { responseMimeType: 'application/json', temperature: 0.2 }
        })
      }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, status: r.status, j: j }; }); })
        .then(function (res) {
          if (!res.ok) {
            var msg = res.j && res.j.error && res.j.error.message || ('HTTP ' + res.status);
            if (res.status === 429) msg = T("Bugungi bepul limit tugadi. Ertaga qayta urinib ko'ring.");
            else if (res.status === 400 || res.status === 403) msg = T("Kalit noto'g'ri yoki faol emas. Sozlamalarni tekshiring.") + ' (' + msg + ')';
            throw new Error(msg);
          }
          var txt = res.j.candidates[0].content.parts.map(function (p) { return p.text || ''; }).join('');
          var data = JSON.parse(txt.replace(/^```json|```$/g, '').trim());
          showResult(data.items || []);
        })
        .catch(function (e) { $('#ps', md).textContent = T('Xato') + ': ' + (e.message || e); $('#pPick', md).disabled = false; });
    }
    function showResult(items) {
      if (!items.length) { $('#ps', md).textContent = T('Rasmda taom aniqlanmadi.'); $('#pPick', md).disabled = false; return; }
      $('#ps', md).textContent = T("Natija taxminiy. Kerak bo'lsa, kaloriyani o'zgartiring.");
      $('#pRes', md).innerHTML = '<div class="card list" style="margin-top:10px">' + items.map(function (it, i) {
        return '<div class="item"><div style="flex:1"><div class="nm">' + esc(it.name) + '</div><div class="muted small">~' + r0(it.grams || 0) + ' ' + T('g') + '</div></div>' +
          '<input type="number" inputmode="decimal" data-k="' + i + '" value="' + r0(it.kcal || 0) + '" style="width:90px"></div>';
      }).join('') + '</div>' + mealSelect() + '<button class="btn block" style="margin-top:12px" id="pAdd">' + T("Hammasini qo'shish") + '</button>';
      $('#pAdd', md).onclick = function () {
        var meal = $('#fMeal', md).value;
        items.forEach(function (it, i) {
          addFood({ name: it.name, kcal: num($('[data-k="' + i + '"]', md).value), p: it.protein, f: it.fat, c: it.carbs, meal: meal, note: '~' + r0(it.grams || 0) + ' ' + T('g') + ' · AI' });
        });
        closeModal(); render(); toast(T("Qo'shildi"));
      };
    }
  }

  // ---------- Mashqlar ----------
  function progTotal(p) { return p.items.reduce(function (a, it) { return a + it[1]; }, 0) + p.rest * (p.items.length - 1); }
  function viewTrain() {
    var h = '<h2>' + T('Mashq dasturlari') + '</h2>';
    PROGRAMS.forEach(function (p) {
      var cls = p.level === 'Yengil' ? '' : p.level === 'Qiyin' ? ' r' : ' o';
      h += '<div class="card prog" data-p="' + p.id + '"><div><b>' + T(p.name) + '</b><div class="muted small">' + p.items.length + ' ' + T('ta mashq') + ' · ~' +
        Math.ceil(progTotal(p) / 60) + ' ' + T('daqiqa') + '</div></div><span class="tag' + cls + '">' + T(p.level) + '</span></div>';
    });
    h += '<h2>' + T('Barcha mashqlar (video bilan)') + '</h2><div class="card">';
    Object.keys(EXERCISES).forEach(function (k) { h += exRow(k); });
    h += '</div>';
    var hist = S.workouts.slice(-10).reverse();
    if (hist.length) {
      h += '<h2>' + T('Oxirgi mashg\'ulotlar') + '</h2><div class="card list">' + hist.map(function (w) {
        return '<div class="item"><div><div class="nm">' + esc(T(w.name)) + '</div><div class="muted small">' + prettyDate(w.d) + '</div></div><span class="muted small">' + w.min + ' ' + T('daq') + ' · ' + w.kcal + ' ' + T('kkal') + '</span></div>';
      }).join('') + '</div>';
    }
    return h;
  }
  function exRow(k, sec) {
    var e = EXERCISES[k];
    return '<div class="ex"><div class="row between"><b>' + T(e.name) + '</b>' + (sec ? '<span class="muted small">' + sec + ' ' + T('soniya') + '</span>' : '') + '</div>' +
      '<div class="muted small">' + T(e.desc) + '</div>' +
      '<div class="vids"><button data-yt="' + esc(e.uz) + '">' + T("O'zbekcha video") + '</button><button data-yt="' + esc(e.ru) + '">' + T('Ruscha video') + '</button></div></div>';
  }
  function bindYt(root) {
    $$('[data-yt]', root).forEach(function (b) {
      b.onclick = function (ev) { ev.stopPropagation(); openUrl('https://www.youtube.com/results?search_query=' + encodeURIComponent(b.getAttribute('data-yt'))); };
    });
  }
  bind.train = function (v) {
    bindYt(v);
    $$('[data-p]', v).forEach(function (c) { c.onclick = function () { progModal(c.getAttribute('data-p')); }; });
  };
  function progModal(id) {
    var p = PROGRAMS.filter(function (x) { return x.id === id; })[0];
    var md = modal(T(p.name),
      '<div class="muted small">' + T('Har mashqdan keyin dam') + ': ' + p.rest + ' ' + T('soniya') + ' · ~' + Math.ceil(progTotal(p) / 60) + ' ' + T('daqiqa') + '</div>' +
      '<button class="btn block" style="margin:12px 0" id="pStart">▶ ' + T('Boshlash') + '</button>' +
      '<div class="card">' + p.items.map(function (it) { return exRow(it[0], it[1]); }).join('') + '</div>');
    bindYt(md);
    $('#pStart', md).onclick = function () { closeModal(); player(p); };
  }

  function beep(f) {
    try {
      var C = window.AudioContext || window.webkitAudioContext; if (!C) return;
      beep.ctx = beep.ctx || new C(); var o = beep.ctx.createOscillator(), g = beep.ctx.createGain();
      o.frequency.value = f || 880; o.connect(g); g.connect(beep.ctx.destination); g.gain.value = 0.15;
      o.start(); o.stop(beep.ctx.currentTime + 0.15);
    } catch (e) {}
  }

  function player(p) {
    var steps = [];
    p.items.forEach(function (it, i) {
      steps.push({ ex: it[0], sec: it[1] });
      if (i < p.items.length - 1) steps.push({ rest: true, sec: p.rest, next: p.items[i + 1][0] });
    });
    var idx = -1, left = 0, paused = false, timer = null, startedAt = Date.now(), activeSec = 0, kcal = 0;
    var md = modal(T(p.name), '<div class="player" id="pl"></div>', function () { clearInterval(timer); if (A && A.keepScreenOn) A.keepScreenOn(false); });
    if (A && A.keepScreenOn) A.keepScreenOn(true);
    function next() {
      idx++;
      if (idx >= steps.length) return finish();
      left = steps[idx].sec; beep(steps[idx].rest ? 520 : 880); vibrate(150); draw();
    }
    function draw() {
      var s = steps[idx], e = EXERCISES[s.rest ? s.next : s.ex];
      var exIdx = 0; for (var i = 0; i <= idx; i++) if (!steps[i].rest) exIdx++;
      $('#pl', md).innerHTML =
        '<div class="dots">' + steps.filter(function (x) { return !x.rest; }).map(function (x, i) { return '<i class="' + (i < exIdx - (s.rest ? 0 : 1) ? 'd' : i === exIdx - 1 && !s.rest ? 'c' : '') + '"></i>'; }).join('') + '</div>' +
        (s.rest ? '<div class="muted">' + T('Dam olish') + '</div><div class="tm rest">' + left + '</div><div class="muted">' + T('Keyingisi') + ':</div><div class="nm">' + T(e.name) + '</div>'
          : '<div class="muted">' + exIdx + ' / ' + p.items.length + '</div><div class="nm">' + T(e.name) + '</div><div class="tm">' + left + '</div><div class="muted small">' + T(e.desc) + '</div>') +
        '<div class="vids" style="margin-top:14px"><button data-yt="' + esc(e.uz) + '">' + T("O'zbekcha video") + '</button><button data-yt="' + esc(e.ru) + '">' + T('Ruscha video') + '</button></div>' +
        '<div class="grid2" style="margin-top:16px"><button class="btn ghost" id="plP">' + T(paused ? 'Davom etish' : 'Pauza') + '</button>' +
        '<button class="btn alt" id="plN">' + T("O'tkazib yuborish") + '</button></div>' +
        '<button class="btn danger block" style="margin-top:10px" id="plS">' + T('Tugatish') + '</button>';
      bindYt(md);
      $('#plP', md).onclick = function () { paused = !paused; draw(); };
      $('#plN', md).onclick = next;
      $('#plS', md).onclick = finish;
    }
    function tick() {
      if (paused || idx < 0 || idx >= steps.length) return;
      var s = steps[idx];
      if (!s.rest) { activeSec++; kcal += EXERCISES[s.ex].met * curWeight() / 3600; }
      left--;
      if (left <= 3 && left > 0) beep(660);
      if (left <= 0) next(); else { var tm = $('.tm', md); if (tm) tm.textContent = left; }
    }
    function finish() {
      clearInterval(timer);
      var min = Math.max(1, Math.round((Date.now() - startedAt) / 60000));
      if (activeSec >= 30) {
        S.workouts.push({ d: dkey(), name: p.name, min: min, kcal: r0(kcal) }); save();
        $('#pl', md).innerHTML = '<div style="font-size:56px">🏆</div><div class="nm">' + T('Barakalla!') + '</div>' +
          '<p class="muted">' + min + ' ' + T('daqiqa') + ' · ~' + r0(kcal) + ' ' + T('kkal sarflandi') + '</p>' +
          '<button class="btn block" id="plD">' + T('Yopish') + '</button>';
      } else {
        $('#pl', md).innerHTML = '<p class="muted">' + T('Mashg\'ulot juda qisqa bo\'ldi, saqlanmadi.') + '</p><button class="btn block" id="plD">' + T('Yopish') + '</button>';
      }
      $('#plD', md).onclick = function () { closeModal(); render(); };
      if (A && A.keepScreenOn) A.keepScreenOn(false);
    }
    timer = setInterval(tick, 1000);
    next();
  }

  // ---------- Vazn ----------
  function viewWeight() {
    var w = lastWeight(), hM = S.profile.height / 100, bmi = w ? w / (hM * hM) : 0;
    var bmiTxt = !bmi ? '' : bmi < 18.5 ? 'Vazn yetishmaydi' : bmi < 25 ? "Me'yorda" : bmi < 30 ? 'Ortiqcha vazn' : 'Semizlik';
    var h = '<div class="card"><label class="f" style="margin-top:0">' + T("Bugungi vazn (kg)") + '</label>' +
      '<div class="row"><input type="number" inputmode="decimal" step="0.1" id="wIn" placeholder="' + (w ? r1(w) : '70.0') + '"><button class="btn" id="wSave">' + T('Saqlash') + '</button></div>' +
      '<div class="muted small" style="margin-top:8px">' + T("Maslahat: har kuni ertalab, nonushtadan oldin tortining.") + '</div></div>';
    h += '<div class="card"><div class="row between"><b>' + T('Vazn grafigi') + '</b><span class="muted small">' + T('Maqsad') + ': ' + S.profile.goalWeight + ' ' + T('kg') + '</span></div>' +
      '<canvas class="chart" id="wChart" style="margin-top:8px"></canvas></div>';
    if (bmi) h += '<div class="card row between"><div><div class="muted small">' + T('Tana massasi indeksi') + '</div><div class="mid">' + r1(bmi) + '</div></div><span class="tag' +
      (bmi >= 18.5 && bmi < 25 ? '' : bmi >= 30 ? ' r' : ' o') + '">' + T(bmiTxt) + '</span></div>';
    if (S.weights.length) {
      h += '<h2>' + T('Tarix') + '</h2><div class="card list">' + S.weights.slice().reverse().slice(0, 60).map(function (x, i, arr) {
        var prev = arr[i + 1], d = prev ? x.kg - prev.kg : 0;
        return '<div class="item"><span>' + prettyDate(x.d) + '</span><div class="row"><b>' + r1(x.kg) + ' ' + T('kg') + '</b>' +
          (prev ? '<span class="small" style="color:' + (d <= 0 ? '#0f9d6b' : '#e8873a') + '">' + (d > 0 ? '+' : '') + r1(d) + '</span>' : '') +
          '<button class="x" data-wd="' + x.d + '">×</button></div></div>';
      }).join('') + '</div>';
    }
    return h;
  }
  bind.weight = function (v) {
    lineChart($('#wChart', v), S.weights.slice(-60), S.profile.goalWeight);
    $('#wSave', v).onclick = function () {
      var kg = num($('#wIn', v).value);
      if (kg < 20 || kg > 400) { toast(T("To'g'ri vazn kiriting")); return; }
      var d = dkey(); S.weights = S.weights.filter(function (x) { return x.d !== d; });
      S.weights.push({ d: d, kg: kg }); S.weights.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      save(); render(); toast(T('Saqlandi'));
    };
    $$('[data-wd]', v).forEach(function (b) {
      b.onclick = function () { var d = b.getAttribute('data-wd'); S.weights = S.weights.filter(function (x) { return x.d !== d; }); save(); render(); };
    });
  };

  // ---------- Sozlamalar ----------
  function profileForm() {
    var p = S.profile;
    return '<label class="f">' + T('Jins') + '</label><div class="seg" id="sSex"><button data-v="m" class="' + (p.sex === 'm' ? 'on' : '') + '">' + T('Erkak') +
      '</button><button data-v="f" class="' + (p.sex === 'f' ? 'on' : '') + '">' + T('Ayol') + '</button></div>' +
      '<div class="grid2"><div><label class="f">' + T('Yosh') + '</label><input type="number" id="sAge" value="' + p.age + '"></div>' +
      '<div><label class="f">' + T("Bo'y (sm)") + '</label><input type="number" id="sH" value="' + p.height + '"></div>' +
      '<div><label class="f">' + T('Hozirgi vazn (kg)') + '</label><input type="number" step="0.1" id="sW" value="' + (lastWeight() || '') + '"></div>' +
      '<div><label class="f">' + T('Maqsad vazn (kg)') + '</label><input type="number" step="0.1" id="sG" value="' + p.goalWeight + '"></div>' +
      '<div><label class="f">' + T('Kunlik qadam maqsadi') + '</label><input type="number" id="sSt" value="' + p.stepGoal + '"></div>' +
      '<div><label class="f">' + T('Kaloriya maqsadi') + '</label><input type="number" id="sK" placeholder="' + esc(T('avto')) + '" value="' + (p.kcalManual || '') + '"></div></div>';
  }
  function readProfile(root) {
    var p = S.profile, on = $('#sSex .on', root);
    p.sex = on ? on.getAttribute('data-v') : p.sex;
    p.age = num($('#sAge', root).value) || p.age; p.height = num($('#sH', root).value) || p.height;
    p.goalWeight = num($('#sG', root).value) || p.goalWeight; p.stepGoal = num($('#sSt', root).value) || p.stepGoal;
    p.kcalManual = num($('#sK', root).value);
    var w = num($('#sW', root).value);
    if (w >= 20 && Math.abs(w - lastWeight()) > 0.01) {
      var d = dkey(); S.weights = S.weights.filter(function (x) { return x.d !== d; }); S.weights.push({ d: d, kg: w });
      S.weights.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
    }
  }
  function bindSeg(root) {
    $$('#sSex button', root).forEach(function (b) {
      b.onclick = function () { $$('#sSex button', root).forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on'); };
    });
  }
  function viewSettings() {
    var p = S.profile;
    return '<h2>' + T('Yozuv') + '</h2><div class="card"><div class="seg" id="sScr"><button data-v="lat" class="' + (S.script === 'lat' ? 'on' : '') + '">Lotin</button>' +
      '<button data-v="cyr" class="' + (S.script === 'cyr' ? 'on' : '') + '">Кирилл</button></div></div>' +
      '<h2>' + T("Shaxsiy ma'lumotlar") + '</h2><div class="card">' + profileForm() +
      '<div class="muted small" style="margin-top:8px">' + T('Hisoblangan kunlik kaloriya') + ': <b>' + kcalGoal() + '</b> ' + T('kkal') + '</div>' +
      '<button class="btn block" style="margin-top:12px" id="sSave">' + T('Saqlash') + '</button></div>' +
      '<h2>' + T('Rasmdan kaloriya ([[Gemini AI]])') + '</h2><div class="card">' +
      '<div class="muted small">' + T("Bepul kalit: [[aistudio.google.com/apikey]]. Kalit faqat shu telefonda saqlanadi.") + '</div>' +
      '<label class="f">' + T('Kalit ([[API key]])') + '</label><input type="password" id="sKey" value="' + esc(p.apiKey) + '" placeholder="AIza...">' +
      '<label class="f">' + T('Model') + '</label><input type="text" id="sModel" value="' + esc(p.model) + '">' +
      '<div class="grid2" style="margin-top:12px"><button class="btn" id="sKeySave">' + T('Saqlash') + '</button><button class="btn alt" id="sKeyGet">' + T('Kalit olish') + '</button></div></div>' +
      '<h2>' + T('Zaxira nusxa') + '</h2><div class="card"><div class="muted small">' + T("Telefon almashtirsangiz, ma'lumotlarni shu yerdan ko'chirib oling.") + '</div>' +
      '<div class="grid2" style="margin-top:10px"><button class="btn alt" id="sExp">' + T('Nusxa olish') + '</button><button class="btn alt" id="sImp">' + T('Tiklash') + '</button></div>' +
      '<button class="btn danger block" style="margin-top:10px" id="sWipe">' + T("Hamma ma'lumotni o'chirish") + '</button></div>' +
      '<div class="muted small" style="text-align:center;margin:16px">' + T('Sihat') + ' 1.0</div>';
  }
  bind.settings = function (v) {
    bindSeg(v);
    $$('#sScr button', v).forEach(function (b) { b.onclick = function () { S.script = b.getAttribute('data-v'); I18N.script = S.script; save(); render(); }; });
    $('#sSave', v).onclick = function () { readProfile(v); save(); render(); toast(T('Saqlandi')); };
    $('#sKeySave', v).onclick = function () { S.profile.apiKey = $('#sKey', v).value.trim(); S.profile.model = $('#sModel', v).value.trim() || 'gemini-2.5-flash'; save(); toast(T('Saqlandi')); };
    $('#sKeyGet', v).onclick = function () { openUrl('https://aistudio.google.com/apikey'); };
    $('#sExp', v).onclick = function () {
      var data = JSON.stringify(S); var md = modal(T('Nusxa olish'), '<div class="muted small">' + T("Matnni nusxalab, Telegram'dagi «Saqlangan xabarlar»ga yuboring.") + '</div>' +
        '<textarea id="eT" readonly>' + esc(data) + '</textarea><button class="btn block" style="margin-top:10px" id="eC">' + T('Nusxalash') + '</button>');
      $('#eC', md).onclick = function () {
        var t = $('#eT', md); t.select();
        if (A && A.copyText) { A.copyText(data); toast(T('Nusxalandi')); }
        else if (navigator.clipboard) navigator.clipboard.writeText(data).then(function () { toast(T('Nusxalandi')); });
        else { document.execCommand('copy'); toast(T('Nusxalandi')); }
      };
    };
    $('#sImp', v).onclick = function () {
      var md = modal(T('Tiklash'), '<div class="muted small">' + T("Avval olingan nusxa matnini shu yerga joylang.") + '</div><textarea id="iT"></textarea>' +
        '<button class="btn block" style="margin-top:10px" id="iG">' + T('Tiklash') + '</button>');
      $('#iG', md).onclick = function () {
        try { var d = JSON.parse($('#iT', md).value); if (!d.profile) throw 0; S = d; I18N.script = S.script; save(); closeModal(); render(); toast(T('Tiklandi')); }
        catch (e) { toast(T("Matn noto'g'ri")); }
      };
    };
    $('#sWipe', v).onclick = function () {
      var md = modal(T("O'chirish"), '<p>' + T("Barcha vazn, ovqat va mashq yozuvlari o'chadi. Davom etasizmi?") + '</p>' +
        '<button class="btn danger block" id="wY">' + T("Ha, o'chirish") + '</button>');
      $('#wY', md).onclick = function () { localStorage.removeItem(KEY); S = load(); I18N.script = S.script; closeModal(); render(); onboard(); };
    };
  };

  // ---------- Modal oynalar ----------
  var modalStack = [];
  function modal(title, body, onClose) {
    var bg = document.createElement('div'); bg.className = 'modal-bg';
    bg.innerHTML = '<div class="modal"><div class="mh"><b>' + esc(title) + '</b><button class="x" data-close>×</button></div>' + body + '</div>';
    $('#modalRoot').appendChild(bg);
    var entry = { el: bg, onClose: onClose };
    modalStack.push(entry);
    $('[data-close]', bg).onclick = closeModal;
    bg.addEventListener('click', function (e) { if (e.target === bg) closeModal(); });
    return bg;
  }
  function closeModal() {
    var m = modalStack.pop();
    if (!m) return false;
    if (m.onClose) try { m.onClose(); } catch (e) {}
    if (m.el && m.el.parentNode) m.el.parentNode.removeChild(m.el);
    return true;
  }
  // Android "orqaga" tugmasi: avval modalni yopadi, keyin bosh sahifaga qaytadi
  window.sihatBack = function () {
    if (closeModal()) return true;
    if (tab !== 'home') { go('home'); return true; }
    return false;
  };
  // Android tomonidan qadamlar yangilanganda chaqiriladi
  window.sihatStepsChanged = function () { if (tab === 'home' && !modalStack.length) render(); };

  // ---------- Birinchi ishga tushirish ----------
  function onboard() {
    if (S.onboarded) return;
    var md = modal(T('Xush kelibsiz!'),
      '<div class="seg" id="sScr0" style="margin-bottom:6px"><button data-v="lat" class="' + (S.script === 'lat' ? 'on' : '') + '">Lotin</button>' +
      '<button data-v="cyr" class="' + (S.script === 'cyr' ? 'on' : '') + '">Кирилл</button></div>' +
      '<div class="muted small">' + T("Kunlik kaloriya me'yorini hisoblash uchun ma'lumotlaringizni kiriting.") + '</div>' + profileForm() +
      '<button class="btn block" style="margin-top:14px" id="oGo">' + T('Boshlash') + '</button>');
    bindSeg(md);
    $$('#sScr0 button', md).forEach(function (b) {
      b.onclick = function () { readProfile(md); S.script = b.getAttribute('data-v'); I18N.script = S.script; save(); closeModal(); render(); onboard(); };
    });
    $('#oGo', md).onclick = function () {
      readProfile(md);
      if (!lastWeight()) { toast(T('Hozirgi vazningizni kiriting')); return; }
      S.onboarded = true; save(); closeModal(); render();
      if (A && A.requestStepPermission) A.requestStepPermission();
    };
  }

  render();
  onboard();
})();
