// Lotin -> Kirill (o'zbek) o'giruvchi. Ilova matnlari lotinda yozilgan,
// foydalanuvchi "Кирилл" tanlasa, ekranga chiqishidan oldin shu yerda o'giriladi.
// [[...]] ichidagi so'zlar (masalan, [[Gemini]]) o'girilmaydi.
(function () {
  var MAP = {
    a: 'а', b: 'б', d: 'д', e: 'е', f: 'ф', g: 'г', h: 'ҳ', i: 'и', j: 'ж',
    k: 'к', l: 'л', m: 'м', n: 'н', o: 'о', p: 'п', q: 'қ', r: 'р', s: 'с',
    t: 'т', u: 'у', v: 'в', x: 'х', y: 'й', z: 'з', c: 'ц', w: 'в'
  };
  var APOS = "'ʻʼ‘’`";

  function isLetter(ch) { return /[a-zA-Z]/.test(ch || ''); }
  function up(src, out) {
    if (src && src[0] !== src[0].toLowerCase()) {
      // Butun so'z katta harfda bo'lsa (masalan, KKAL) hammasi katta qolsin
      return out.charAt(0).toUpperCase() + out.slice(1);
    }
    return out;
  }

  function word(w) {
    var res = '', i = 0, lw = w.toLowerCase(), allCaps = w.length > 1 && w === w.toUpperCase() && /[A-Z]/.test(w);
    while (i < w.length) {
      var c = lw[i], n = lw[i + 1], orig = w[i], piece = null, step = 1;
      if ((c === 'o' || c === 'g') && n && APOS.indexOf(n) >= 0) {
        piece = c === 'o' ? 'ў' : 'ғ'; step = 2;
      } else if (c === 's' && n === 'h') { piece = 'ш'; step = 2; }
      else if (c === 'c' && n === 'h') { piece = 'ч'; step = 2; }
      else if (c === 'y' && n === 'o') { piece = 'ё'; step = 2; }
      else if (c === 'y' && n === 'u') { piece = 'ю'; step = 2; }
      else if (c === 'y' && n === 'a') { piece = 'я'; step = 2; }
      else if (c === 'y' && n === 'e') { piece = 'е'; step = 2; }
      else if (c === 'e' && i === 0) { piece = 'э'; }
      else if (APOS.indexOf(c) >= 0) { piece = 'ъ'; }
      else if (MAP[c]) { piece = MAP[c]; }
      else { piece = orig; }
      if (MAP[c] || piece !== orig) piece = up(orig, piece);
      res += piece; i += step;
    }
    return allCaps ? res.toUpperCase() : res;
  }

  function toCyr(text) {
    if (!text) return text;
    var parts = String(text).split(/(\[\[.*?\]\])/);
    return parts.map(function (p) {
      if (p.indexOf('[[') === 0) return p.slice(2, -2);
      return p.replace(/[A-Za-z][A-Za-z'ʻʼ‘’`]*/g, function (w) {
        // so'z oxiridagi tutuq belgisi emas, qo'shtirnoq bo'lishi mumkin
        var tail = '';
        while (w.length > 1 && APOS.indexOf(w[w.length - 1]) >= 0 && !/[og]$/i.test(w.slice(0, -1))) {
          tail = w[w.length - 1] + tail; w = w.slice(0, -1);
        }
        return word(w) + tail;
      });
    }).join('');
  }

  function stripMarks(text) { return String(text).replace(/\[\[(.*?)\]\]/g, '$1'); }

  window.I18N = {
    script: 'lat',
    t: function (s) { return this.script === 'cyr' ? toCyr(s) : stripMarks(s); },
    toCyr: toCyr
  };
})();
