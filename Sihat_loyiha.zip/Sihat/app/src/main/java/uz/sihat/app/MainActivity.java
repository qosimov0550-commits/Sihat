package uz.sihat.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Sihat — sport va vazn nazorati.
 * Interfeys assets/www ichidagi veb sahifa; bu klass unga qadam sensori,
 * kamera, tebranish va tashqi havolalarni ochishni ulaydi.
 */
public class MainActivity extends Activity implements SensorEventListener {

    // Sahifalar soxta https manzildan beriladi: kamera va internet so'rovlari
    // xavfsiz (secure) muhit talab qiladi, file:// da ular ishlamaydi.
    private static final String HOST = "sihat.local";
    private static final String START_URL = "https://" + HOST + "/index.html";

    private static final int REQ_CAMERA = 11;
    private static final int REQ_STEPS = 12;
    private static final int REQ_FILE = 13;

    private WebView web;
    private SensorManager sensorManager;
    private Sensor stepSensor;
    private SharedPreferences prefs;
    private PermissionRequest pendingCamera;
    private ValueCallback<Uri[]> fileCallback;
    private long lastNotify = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#F4F6F5"));
        getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        prefs = getSharedPreferences("steps", MODE_PRIVATE);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new LocalClient());
        web.setWebChromeClient(new Chrome());
        web.loadUrl(START_URL);
    }

    // ---------- Lokal fayllarni berish ----------
    private class LocalClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (!HOST.equals(u.getHost())) return null;
            String path = u.getPath();
            if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
            try {
                InputStream in = getAssets().open("www" + path);
                return new WebResourceResponse(mime(path), "utf-8", in);
            } catch (IOException e) {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null,
                        new ByteArrayInputStream(new byte[0]));
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (HOST.equals(u.getHost())) return false;
            openExternal(u.toString());
            return true;
        }
    }

    private static String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    private void openExternal(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) { }
    }

    // ---------- Kamera va galereya ----------
    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(request.getResources());
                } else {
                    pendingCamera = request;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                }
            });
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                startActivityForResult(Intent.createChooser(pick, null), REQ_FILE);
            } catch (Exception e) {
                fileCallback = null;
                return false;
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_CAMERA && pendingCamera != null) {
            if (ok) pendingCamera.grant(pendingCamera.getResources());
            else pendingCamera.deny();
            pendingCamera = null;
        } else if (requestCode == REQ_STEPS) {
            registerSteps();
            notifyJs(true);
        }
    }

    // ---------- Qadam sanash ----------
    // TYPE_STEP_COUNTER telefon yoqilgandan beri jami qadamlarni beradi va
    // ilova yopiq bo'lsa ham sanab boradi. Biz oxirgi qiymat bilan farqni
    // bugungi kunga qo'shib boramiz.
    private void registerSteps() {
        if (sensorManager != null && stepSensor != null) {
            sensorManager.unregisterListener(this);
            sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI);
        }
    }

    private boolean needsStepPermission() {
        return Build.VERSION.SDK_INT >= 29
                && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED;
    }

    private static String day(Date d) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_STEP_COUNTER) return;
        long total = (long) event.values[0];
        String today = day(new Date());
        long last = prefs.getLong("last_total", -1);
        long todaySteps = prefs.getLong("steps_" + today, 0);
        if (last >= 0) {
            long delta = total - last;
            if (delta < 0) delta = total; // telefon qayta yoqilgan
            if (delta > 0 && delta < 100000) todaySteps += delta;
        }
        prefs.edit()
                .putLong("steps_" + today, todaySteps)
                .putLong("last_total", total)
                .apply();
        notifyJs(false);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private void notifyJs(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastNotify < 4000) return;
        lastNotify = now;
        runOnUiThread(() -> web.evaluateJavascript("window.sihatStepsChanged && window.sihatStepsChanged()", null));
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        registerSteps();
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
        if (sensorManager != null) sensorManager.unregisterListener(this);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.sihatBack ? window.sihatBack() : false", value -> {
            if (!"true".equals(value)) super.onBackPressed();
        });
    }

    // ---------- JavaScript uchun ko'prik (window.Android) ----------
    private class Bridge {
        @JavascriptInterface
        public int getStepsToday() {
            return (int) prefs.getLong("steps_" + day(new Date()), 0);
        }

        @JavascriptInterface
        public String getStepHistory() {
            StringBuilder sb = new StringBuilder("{");
            Calendar c = Calendar.getInstance();
            for (int i = 0; i < 60; i++) {
                String d = day(c.getTime());
                long v = prefs.getLong("steps_" + d, 0);
                if (v > 0) {
                    if (sb.length() > 1) sb.append(',');
                    sb.append('"').append(d).append("\":").append(v);
                }
                c.add(Calendar.DAY_OF_MONTH, -1);
            }
            return sb.append('}').toString();
        }

        @JavascriptInterface
        public boolean hasStepSensor() { return stepSensor != null; }

        @JavascriptInterface
        public boolean needsStepPermission() { return MainActivity.this.needsStepPermission(); }

        @JavascriptInterface
        public void requestStepPermission() {
            if (Build.VERSION.SDK_INT >= 29 && MainActivity.this.needsStepPermission()) {
                runOnUiThread(() -> requestPermissions(
                        new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQ_STEPS));
            }
        }

        @JavascriptInterface
        public void openUrl(String url) { runOnUiThread(() -> openExternal(url)); }

        @JavascriptInterface
        public void vibrate(int ms) {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
        }

        @JavascriptInterface
        public void keepScreenOn(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Sihat", text));
            });
        }
    }
}
